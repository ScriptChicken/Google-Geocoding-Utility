from bs4 import BeautifulSoup
from xml.etree import ElementTree
import xml.etree.ElementTree as ET


#Sets the inputed Google Geocode API key into the settings.xml file.
def setAPI(data):
	try:
		filename = "settings.xml"
		tree = ET.parse(filename)
		root = tree.getroot()
		
		for row in root.findall("API"):
			if row.find('title').text == 'current_api':
				row.find('active').text = data
				
		tree.write(filename,encoding='UTF-8',xml_declaration=True)
		print("Successfully saved API Key!")
	except:
		input("Something went wrong trying to save your input, please make sure the settings.xml file is in the root of your executable.")
		exit()


#Gets the currently saved Google Geocode API key from the settings.xml file.
def getAPI():
	try:
		filename = "settings.xml"
		tree = ET.parse(filename)
		root = tree.getroot()
		
		for row in root.findall("API"):
			if row.find('title').text == 'current_api':
				data = row.find('active').text
		return data
	except:
		input("Something went wrong trying to read your current API Key, pleae make sure the settings.xml file is in the root of your executable.")
		exit()


#Deletes the currently saved Google Geocode API key from the settings.xml file.
def deleteAPI():
	try:
		filename = "settings.xml"
		tree = ET.parse(filename)
		root = tree.getroot()
		
		for row in root.findall("API"):
			if row.find('title').text == 'current_api':
				row.find('active').text = ""
				
		tree.write(filename,encoding='UTF-8',xml_declaration=True)
		input("Successfully deleted API Key, please restart the application!")
	except:
		input("Something went wrong trying to delete your API Key, please make sure the settings.xml file is in the root of your executable.")
		exit()

