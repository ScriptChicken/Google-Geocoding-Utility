import googlemaps
import csv
import msvcrt
import visuals
import os
import parseXML
getch = msvcrt.getch

#variables
m = 0

def checkAPI():
	visuals.opt_bar(title="Loading Google Geocoding Utility",length=10,char=".",speed=.5,clr_scn=1)
	try:
		current_api = parseXML.getAPI()
		if current_api == None:
			while True:
				print("\nHow to setup Google API Key: https://www.youtube.com/watch?v=OGTG1l7yin4")
				i = input("\nPlease enter your Google Geocoding API key: ")
				x = input("\nSave to settings? y/n ('e' to exit): " + i + " ")
				if x == "y":
					parseXML.setAPI(i)
					input("API is now set to: " + parseXML.getAPI())
					return
				elif x == "e":
					exit()
				else:
					input("That wasn't an option, try again!")
	except:
		input("There was a problem trying to verify your saved API, please make sure you have a settings.xml file within the root of this program folder.")
		exit()


def menu():
	while True:
		os.system('cls')
		title = "Google Geocoding Utility"
		var1 = "1: Create Output File"
		var2 = "2: Delete saved API key"
		var3 = "'e' to exit"
		var = [var1,var2,var3]
		visuals.opt_frame(var,title, length=10,color="0",align="left",left_margin=m)
		
		print("\n" + margin(m) + "Choose an option: ")
		inpt = getch()
		
		if str(inpt) == "b'1'":
			doWork()
		elif str(inpt) == "b'2'":
			parseXML.deleteAPI()
			exit()
		elif str(inpt) == "b'e'":
			exit()
		else:
			input("That wasn't an option, try again...")


def doWork():
	nu_columns = []
	fname = input("\n" + margin(m) + "Enter the name of the file to be geocoded (must have CSV extension and be saved in the folder where this executable is stored): ")
	print("\n" + margin(m) + "entered filename: " + fname)
	inpt2 = input("\n" + margin(m) + "Geocode above filename? y/n: ")
	if inpt2 == 'y':
		print("Please choose the columns you would like to append to your ouput file.")
		columns = getallColumns(fname)
		for row in columns:
			print(f"{C.Y}\n" + margin(m) + "output '" + row + f"'? y/n {C.E}")
			x = getch()
			if str(x) == "b'y'":
				nu_columns.append(row)
				print("\n" + margin(m) + f"{C.G}added.{C.E}")
		nu_columns.append("lat")
		nu_columns.append("long")
		input("\n" + margin(m) + f"{C.Y}Column data collected.  Press enter to create output file.{C.E}")
		writeSelected(fname,columns)
		sortFile(fname,nu_columns)
		input("\n" + margin(m) + f"{C.G}Output.csv created successfully" + f"{C.E}")
		return


	elif inpt2 == 'n':
		return
	else:
		input("\n" + margin(m) + "That wasn't an option, try again....")


#Creates a temp file and does the geocoding on the given 'addresses' column and writes it out to the temp file
def writeSelected(fname,columns):
	g_API = parseXML.getAPI()
	gmaps_key = googlemaps.Client(key=g_API)
	l = 0	
	try:
		f = open('temp.csv', 'w', newline='')
		writer = csv.writer(f)
			
		filename = open(fname, 'r',encoding='utf-8-sig')
		file = csv.reader(filename)

		for r in file:
			if "addresses" not in r and r[0] != columns[0]:
				try:
					print("attempting to find coordinates for: " + r[l])
					geocode_obj = gmaps_key.geocode(r[l])
					lat = geocode_obj[0]['geometry']['location']['lat']
					lon = geocode_obj[0]['geometry']['location']['lng']
					if lat != None and lon != None:
						print(f"{C.G}Coordinates found!{C.E}")
						r.append(lat)
						r.append(lon)
						writer.writerow(r)
			
				except:
					print(f"{C.R}Coordinates not found!{C.E}")
					r.append("No Coordinates")
					r.append("No Coordinates")
					writer.writerow(r)
						
			else:
				l = r.index("addresses")
				r.append("lat")
				r.append("long")
				writer.writerow(r)
		f.close()
	except ValueError:
		input(f"{C.R}Opps, did you forget to choose an 'addresses' column?  Please try again.{C.E}")
		exit()
	except:
		input(f"{C.R}There was an error trying to geocode your addresses.  Please try again.{C.E}")
		exit()


#Creates the final output file but only writes out the choosen fields from the menu.
def sortFile(fname,list_a):
	try:
		o = open('output.csv', 'w', newline='')
		writer = csv.DictWriter(o, extrasaction="ignore", fieldnames = list_a)
		writer.writeheader()
		t = open('temp.csv', 'r',encoding='utf-8-sig')
		file = csv.DictReader(t)
		for row in file:
			writer.writerow(row)
		o.close()
		t.close()
		os.remove('temp.csv')
		return
	except:
		input(f"{C.R}There was an error trying to sort the file.  Please try again.{C.E}")
		exit()



#Gets the first row of the CSV (Title bar)
def getallColumns(fname):
	try:
		filename = open(fname, 'r',encoding='utf-8-sig')
		#Read through the file
		file = csv.reader(filename)

		for row in file:
			columns = row
			return columns
	except:
		input("\nThere was a problem trying to get columns from your file.  Please make sure your file is in the same folder as this executable.")
		exit()

def margin(x):
	mar = " " * x
	return mar

class C:
	H = '\033[95m'
	B = '\033[94m'
	C = '\033[96m'
	G = '\033[92m'
	Y = '\033[93m'
	R = '\033[91m'
	P = '\033[95m'
	E = '\033[0m'
	BOLD = '\033[1m'
	UNDERLINE = '\033[4m'

checkAPI()
menu()